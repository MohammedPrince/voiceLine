<?php $__env->startSection('content'); ?>
     <body>
    <H1>CMC</H1>    
    </body> 



<body>
  
 
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Amani\Desktop\voiceline-dev (1)\voiceline-dev\resources\views/calls/create.blade.php ENDPATH**/ ?>
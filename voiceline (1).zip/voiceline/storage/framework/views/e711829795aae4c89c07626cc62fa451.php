  
<?php $__env->startSection('title', 'Home Page'); ?>
 
<?php $__env->startSection('content'); ?>
  <div class="choices">
        
<a class="choice" href="<?php echo e(route('calls.create')); ?>">
        <span>User Management </span>
    </a>
    <!-- Optional additional nav items -->
    <a class="choice" href="<?php echo e(url('reports/')); ?>">
        <span>Reports</span>
    </a>
    <a class="choice" href="<?php echo e(route('student')); ?>">
        <span>Call Entry</span>
    </a>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Amani\Desktop\voiceline-dev (1)\voiceline-dev\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fu System - Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
  <style>
    /* Additional styles if needed */
    .form-check-label {
      color: #6C3A30;
      font-size: 12px;
    }
    .forgot-password-link {
      color: #6C3A30;
      text-decoration: none;
      display: block;
      text-align: right;
      margin-top: 5px;
      margin-bottom: 15px;
    }
    .forgot-password-link:hover {
      text-decoration: underline;
    }
    .btn-outline {
      background-color: #6C3A30;
      color: white;
      border: none;
    }
    .btn-outline:hover {
      background-color: #8a4d3f;
      color: white;
    }
  </style>
</head>

<body>
  <picture>
    <source srcset="<?php echo e(asset('assets/logowithname.svg')); ?>" type="image/svg+xml">
    <img src="<?php echo e(asset('assets/logowithname.svg')); ?>" class="logo" alt="logo" draggable="false">
  </picture>

  <!-- Top-left image -->
  <img src="<?php echo e(asset('assets/bottomleft.svg')); ?>" class="bottom-left" alt="bottomleft" draggable="false">

  <!-- Bottom-right image -->
  <img src="<?php echo e(asset('assets/topright.svg')); ?>" class="top-right" alt="topright" draggable="false">

  <!-- Form Container -->
  <div class="container col-12" style="flex-direction: row;">
    <div class="row g-0 col-12">
      <div class="left-form col-4 align-content-center">
        
        <!-- Session Status -->
        <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
           
        <form method="POST" action="<?php echo e(route('login')); ?>">
        
          <?php echo csrf_field(); ?>
          
          <figure class="text-center">
            <blockquote class="blockquote">
              <h2 style="color: #6C3A30; margin-top: 40px; margin-bottom: 20px;user-select: none; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none;"
                data-i18n="welcomeback">Welcome Back</h2>
            </blockquote>
          </figure>
          
          <div class="text-overlay"></div>

          <!-- Email Address -->
          <label for="email" class="form-label"
            style="color: #B77848;user-select: none; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none;"
            data-i18n="username">Username</label>
          <input type="email" class="form-control form-control-sm" id="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger mt-1"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

          <!-- Password -->
          <label for="password" class="form-label mt-3"
            style="color: #B77848;user-select: none; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none;"
            data-i18n="password">Password</label>
          <input type="password" id="password" name="password" class="form-control form-control-sm" required autocomplete="current-password">
          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger mt-1"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

          <!-- <?php if(Route::has('password.request')): ?>
            <a href="<?php echo e(route('password.request')); ?>" class="forgot-password-link" data-i18n="forgot">Forgot password?</a>
          <?php endif; ?> -->

          <!-- Remember Me -->
          <div class="form-check mt-2">
            <input class="form-check-input small" type="checkbox" id="remember_me" name="remember">
            <label class="form-check-label" for="remember_me" data-i18n="remember">
              Remember my username
            </label>
          </div>

          <button type="submit" class="btn btn-outline mt-3" data-i18n="login" style="width: 220px;margin-top: 10px;">Login</button>
        </form>
      </div>

      <div class="img-container col-8 g-0 d-none d-md-block">
        <img src="<?php echo e(asset('assets/paintinglogin2.svg')); ?>" alt="Welcome illustration" draggable="false">
        <h2 class="text-overlay" data-i18n="welcomecampus">Welcome to VoiceLine</h2>
      </div>
    </div>
  </div>

  <script src="<?php echo e(asset('js/localization.js')); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
</body>

</html><?php /**PATH C:\Users\Amani\Desktop\voiceline-dev (1)\voiceline-dev\resources\views/auth/login.blade.php ENDPATH**/ ?>
@extends('layouts.app')

@section('title', 'Home Page')

@section('content')
  <h1>Welcome to FU System</h1>
  <p>This is the home page content.</p>
@endsection
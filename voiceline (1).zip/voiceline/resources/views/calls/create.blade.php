
@extends('layouts.app')

@section('content')
     <body>
    <H1>CMC</H1>    
    </body> 



<body>
  
 
 @endsection